export const ChatgptTokenTutorialUrl =
  'https://www.bilibili.com/video/BV1fD421M7xP/?share_source=copy_web&vd_source=4c37761f5ba7612e942a84820f8099f6';

export const ChatgptTokenAuthUrl = 'https://chat.openai.com/auth/';
