export default {
  markDay: '下午好，今天是你加入鹅厂的第 100 天',
  personalInfo: {
    title: '个人信息',
    position: '港澳业务拓展组员工 直客销售 ',
    desc: {
      phone: '座机',
      mobile: '手机',
      seat: '座位',
      email: '邮箱',
      position: '职位',
      leader: '上级',
      entity: '主体',
      joinDay: '入职时间',
      group: '所属团队',
    },
  },
  visitData: '首页访问数据',
  contentList: '内容列表',
  teamMember: '团队成员',
  serviceProduction: '服务产品',
};
