export default {
  baseInfo: {
    title: '基本信息',
  },
  changelog: {
    title: '变更记录',
    step1: {
      title: '上传合同附件',
      subtitle: '这里是提示文字',
    },
    step2: {
      title: '修改合同金额',
      subtitle: '这里是提示文字',
    },
    step3: {
      title: '新建合同',
      desc: '管理员-李川操作',
    },
  },
};
