export default {
  create: '新建产品',
  placeholder: '请输入内容搜索',
  productName: '产品名称',
  productStatus: '产品状态',
  productDescription: '产品描述',
  productType: '产品类型',
  productRemark: '备注',
  productStatusEnum: {
    off: '停用',
    on: '启用',
  },
};
