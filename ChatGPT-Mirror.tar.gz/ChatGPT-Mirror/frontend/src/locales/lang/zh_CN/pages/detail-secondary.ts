export default {
  read: '已读通知',
  unread: '未读通知',
  all: '全部通知',
  setRead: '设为已读',
  setUnread: '设为未读',
  delete: '删除通知',
  empty: '暂无通知',
};
