export default {
  placeholder: '请输入内容进行搜索',
};
