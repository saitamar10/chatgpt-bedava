export default {
  read: 'Okundu',
  unread: 'Okunmadı',
  all: 'Hepsi',
  setRead: 'okundu olarak işaretle',
  setUnread: 'okunmadı olarak işaretle',
  delete: 'sil',
  empty: 'Boş',
};
