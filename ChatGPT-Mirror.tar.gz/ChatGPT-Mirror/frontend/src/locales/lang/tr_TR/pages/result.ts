export default {
  403: {
    tips: 'Üzgünüz, bu sayfaya erişim izniniz yok. Lütfen yaratıcının WeCom üzerinden iletişime geçin',
    back: 'Ana sayfaya dön',
  },
  404: {
    subtitle: 'Üzgünüz, sayfa bulunamadı',
    back: 'Ana sayfaya dön',
  },
  500: {
    subtitle: 'Üzgünüz, sunucu hatası oluştu',
    back: 'Ana sayfaya dön',
  },
  fail: {
    title: 'Oluşturma başarısız',
    subtitle: 'Üzgünüz, proje oluşturma işleminiz başarısız oldu',
    back: 'Ana sayfaya dön',
    modify: 'Düzenlemeye geri dön',
  },
  success: {
    title: 'Proje oluşturuldu',
    subtitle: 'Uygulama dağıtımından sorumlu kişiyle iletişime geçin',
    back: 'Ana sayfaya dön',
    progress: 'İlerlemi kontrol et',
  },
  maintenance: {
    title: 'Sistem Bakımı',
    subtitle: 'Lütfen daha sonra tekrar deneyin',
    back: 'Ana sayfaya dön',
  },
  browserIncompatible: {
    title: 'Tarayıcı uyumsuz',
    subtitle: 'Kullandığınız tarayıcı sürümü, mevcut web sayfasını açmak için çok eski.',
    back: 'Ana sayfaya dön',
    recommend: 'TDesign Starter aşağıdaki tarayıcıyı önerir',
  },
  networkError: {
    title: 'Ağ Hatası',
    subtitle: 'Ağ hatası, lütfen daha sonra tekrar deneyin',
    back: 'Ana sayfaya dön',
    reload: 'Yenile',
  },
};
