export default {
  baseInfo: {
    title: 'Temel Bilgi',
  },
  invoice: {
    title: 'Fatura İlerleme Durumu',
    step1: {
      title: 'Başvur',
      content: 'Elektronik fatura 21 Aralık’ta gönderildi.',
    },
    step2: {
      title: 'Elektronik Fatura',
      content: '1-3 iş günü içinde işlenmesi bekleniyor.',
    },
    step3: {
      title: 'Fatura Gönderildi',
      content: '7 iş günü içinde sizinle iletişime geçeceğiz.',
    },
    step4: {
      title: 'Tamamlandı',
    },
  },
  product: {
    title: 'Ürün Kategorisi',
    add: 'üretim ekle',
    month: 'ay',
    quarter: 'çeyrek',
  },
  detail: {
    title: 'Ürün Tedarik Detayı',
    form: {
      applyNo: 'Başvuru No',
      product: 'Adı',
      productNo: 'No.',
      department: 'Dep
