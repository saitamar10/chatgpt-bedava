export default {
  create: 'Ürün Oluştur',
  placeholder: 'arama için lütfen girin',
  productName: 'Ad',
  productStatus: 'Durum',
  productDescription: 'Açıklama',
  productType: 'Tür',
  productRemark: 'Not',
  productStatusEnum: {
    off: 'kapalı',
    on: 'açık',
  },
};
