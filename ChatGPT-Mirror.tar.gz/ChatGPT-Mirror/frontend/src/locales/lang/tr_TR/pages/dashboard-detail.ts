export default {
  topPanel: {
    title: 'Bu Ayki Satın Alma Başvuruları',
    quarter: 'Çeyrekten Çeyreğe',
    paneList: {
      totalRequest: 'Başvuru Sayısı',
      suppliers: 'Tedarikçi Sayısı',
      productCategory: 'Ürün Kategorisi',
      applicant: 'Başvuru Sayısı',
      completionRate: 'Tamamlama Oranı(%)',
      arrivalRate: 'Varış Oranı(%)',
    },
  },
  procurement: {
    title: 'Malzeme Satın Alma Taleplerindeki Eğilimler',
    goods: {
      cup: 'bardak',
      tea: 'çay',
      honey: 'bal',
      flour: 'un',
      coffeeMachine: 'kahve makinesi',
      massageMachine: 'masaj makinesi',
    },
  },
  ssl: 'SSL sertifikası',
  sslDescription:
    'SSL sertifikası, diğer adıyla sunucu sertifikası, bir web sitesinin kimliğini doğrulayan ve sunucuya gönderilen bilgileri SSL teknolojisi kullanarak şifreleyen bir dijital sertifikadır. Tencent Cloud, hem ücretsiz hem de ücretli sertifikaların başvuru, yönetim ve dağıtımını içeren tek durak hizmet sunar.',
  satisfaction: {
    title: 'Satın Alınan Ürünlerin Memnuniyet Dağılımı',
    export: 'veriyi dışa aktar',
  },
  chart: {
    week1: 'PZT',
    week2: 'SAL',
    week3: 'ÇAR',
    week4: 'PER',
    week5: 'CUM',
    week6: 'CTS',
    week7: 'PAZ',
    max: 'Maks',
    min: 'Min',
    thisMonth: 'bu ay',
    lastMonth: 'geçen ay',
  },
};
