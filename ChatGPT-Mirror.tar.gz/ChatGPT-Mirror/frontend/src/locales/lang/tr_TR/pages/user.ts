export default {
  markDay: 'İyi akşamlar, bugün Tencentteki 100. gününüzü kutluyoruz',
  personalInfo: {
    title: 'Kişisel Bilgiler',
    position: 'Hong Kong ve Makao İş Genişletme ekibinin çalışanı',

    desc: {
      phone: 'Telefon',
      mobile: 'Cep Telefonu',
      seat: 'Koltuk',
      email: 'E-posta',
      position: 'Pozisyon',
      leader: 'Lider',
      entity: 'Varlık',
      joinDay: 'Katılım Günü',
      group: 'Grup',
    },
  },
  contentList: 'İçerik Listesi',
  visitData: 'Ziyaret Verileri',
  teamMember: 'Ekip Üyesi',
  serviceProduction: 'Hizmet Ürünü',
};
