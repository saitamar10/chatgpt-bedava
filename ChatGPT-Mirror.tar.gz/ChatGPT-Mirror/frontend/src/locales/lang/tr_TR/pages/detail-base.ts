export default {
  baseInfo: {
    title: 'Temel Bilgi',
  },
  changelog: {
    title: 'Değişiklik Kaydı',
    step1: {
      title: 'dosya yükle',
      subtitle: 'alt başlık',
    },
    step2: {
      title: 'sözleşme miktarını düzenle',
      subtitle: 'alt başlık',
    },
    step3: {
      title: 'sözleşme oluştur',
      desc: 'yönetici',
    },
  },
};
