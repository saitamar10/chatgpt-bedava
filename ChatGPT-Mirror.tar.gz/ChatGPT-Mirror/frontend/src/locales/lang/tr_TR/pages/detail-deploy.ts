export default {
  deployTrend: {
    title: 'Dağıtım Eğilimi',
    warning: 'Uyarı',
    thisMonth: 'bu ay',
    thisWeek: 'bu hafta',
    lastMonth: 'geçen ay',
    thisYear: 'bu yıl',
    lastYear: 'geçen yıl',
    week1: 'PZT',
    week2: 'SAL',
    week3: 'ÇAR',
    week4: 'PER',
    week5: 'CUM',
    week6: 'CMT',
    week7: 'PZR',
  },
  projectList: {
    title: 'Proje Listesi',
    dialog: {
      title: 'Temel Bilgiler',
    },
    table: {
      name: 'Ad',
      admin: 'Yönetici',
      createTime: 'Oluşturma Zamanı',
      operation: 'İşlem',
      manage: 'yönet',
      delete: 'sil',
    },
  },
};

