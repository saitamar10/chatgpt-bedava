export default {
  placeholder: 'Lütfen Arayın.',
};
