export default {
  header: {
    code: 'Kod Deposu',
    help: 'Döküman',
    user: 'Profil',
    signOut: 'Çıkış Yap',
    setting: 'Ayarlar',
  },
  notice: {
    title: 'Bildirim Merkezi',
    clear: 'Temizle',
    setRead: 'Okundu Olarak İşaretle',
    empty: 'Boş',
    emptyNotice: 'Bildirim Yok',
    viewAll: 'Tümünü Görüntüle',
  },
  tagTabs: {
    closeOther: 'diğerlerini kapat',
    closeLeft: 'soldakileri kapat',
    closeRight: 'sağdakileri kapat',
    refresh: 'yenile',
  },
  searchPlaceholder: 'Arama içeriği girin',
  setting: {
    title: 'Ayarlar',
    theme: {
      mode: 'Tema Modu',
      color: 'Tema Rengi',
      options: {
        light: 'Açık',
        dark: 'Koyu',
        auto: 'Sistem Ayarını İzle',
      },
    },
    navigationLayout: 'Navigasyon Düzeni',
    sideMode: 'Yan Menü Modu',
    splitMenu: 'Bölünmüş Menü（Sadece Karışık Modda）',
    fixedSidebar: 'Sabit Yan Çubuk',
    element: {
      title: 'Element Seçenekleri',
      showHeader: 'Başlığı Göster',
      showBreadcrumb: 'Navigasyonu Göster',
      showFooter: 'Alt Bilgiyi Göster',
      useTagTabs: 'Sekme Çubuklarını Kullan',
    },
    tips: 'Lütfen yapılandırma dosyasını kopyalayıp manuel olarak düzenleyin: /src/config/style.ts',
    copy: {
      title: 'Kopyala',
      success: 'kopyalandı',
      fail: 'kopyalama başarısız',
    },
  },
};
