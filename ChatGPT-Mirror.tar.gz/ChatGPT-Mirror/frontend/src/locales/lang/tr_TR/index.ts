import merge from 'lodash/merge';
import componentsLocale from 'tdesign-vue-next/es/locale/en_US';

import components from './components';
import layout from './layout';
import pages from './pages';

export default {
  lang: 'Turkce',
  layout,
  pages,
  components,
  constants: {
    contract: {
      name: 'İsim',
      status: 'Durum',
      num: 'Numara',
      type: 'Tür',
      typePlaceholder: 'Lütfen tür girin',
      payType: 'Ödeme Türü',
      amount: 'Miktar',
      amountPlaceholder: 'Lütfen miktar girin',
      signDate: 'İmza Tarihi',
      effectiveDate: 'Geçerlilik Tarihi',
      endDate: 'Bitiş Tarihi',
      createDate: 'Oluşturma Tarihi',
      attachment: 'Ek',
      company: 'Şirket',
      employee: 'Çalışan',
      pay: 'ödeme',
      receive: 'alındı',
      remark: 'açıklama',
      statusOptions: {
        fail: 'Başarısız',
        auditPending: 'Denetim Bekleniyor',
        execPending: 'İcra Bekleniyor',
        executing: 'Başarılı',
        finish: 'Bitti',
      },
      typeOptions: {
        main: 'Ana sözleşme',
        sub: 'Alt sözleşme',
        supplement: 'Ek sözleşme',
      },

      },
    },
  },
  componentsLocale: merge({}, componentsLocale, {
    // 可以在此处定义更多自定义配置，具体可配置内容参看 API 文档
    // https://tdesign.tencent.com/vue-next/config?tab=api
    // pagination: {
    //   jumpTo: 'xxx'
    // },
  }),
};
