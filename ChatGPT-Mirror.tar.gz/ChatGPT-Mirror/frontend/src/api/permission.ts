export function getMenuList() {
  return {
    list: [{}],
  };
}
