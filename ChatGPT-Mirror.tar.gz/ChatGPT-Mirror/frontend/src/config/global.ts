export const prefix = 'tdesign-starter';
